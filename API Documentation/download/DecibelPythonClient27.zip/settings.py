applicationID = '<Your Application ID>'
applicationKey = '<Your Application Key>'
apiAddress = 'http://decibel-rest-jazz.cloudapp.net/v1/'